import android, time

droid = android.Android()

while 1:
	droid.makeToast("Hello from Python 2.7 for Android")
	time.sleep(5)