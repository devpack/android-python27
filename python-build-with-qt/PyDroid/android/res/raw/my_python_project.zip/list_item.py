from PyQt4 import QtCore
from PyQt4 import QtGui
from PyQt4 import QtDeclarative

class TodoItem(QtCore.QObject):

    contentChanged = QtCore.pyqtSignal()
    
    def __init__(self):
        super(TodoItem, self).__init__()

        self._item_text = ''

    @QtCore.pyqtProperty(QtCore.QString, notify=contentChanged)
    def item_text(self):
        return self._item_text

    def set_text(self, txt):
        if self._item_text != txt:
            self._item_text = txt
            self.contentChanged.emit()
